Expansions: These are turned off by default as these are expansions to the level system.
The level system is the first and true set of core features.  These are merely option
items that go along side it or can be integrated into it.  