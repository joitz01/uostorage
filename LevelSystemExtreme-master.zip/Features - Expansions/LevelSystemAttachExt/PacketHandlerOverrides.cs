using System;
using System.IO;
using System.Text;
using Server;
using Server.Network;
using Server.Items;
using Server.Mobiles;
using Server.Engines.Quests;
using Server.Engines.LevelSystemExtAtt;



namespace Server.Engines.LevelSystemExtAtt
{

    public class PacketHandlerOverrides
    {
        public static void Initialize()
        {
            Timer.DelayCall( TimeSpan.Zero, new TimerCallback( UseReqOverride ) );
        }


        public static void UseReqOverride()
        {
            PacketHandlers.Register(0x06, 5, true, new OnPacketReceive(XmlAttachExt.UseReq));
#if(CLIENT6017)
            PacketHandlers.Register6017(0x06, 5, true, new OnPacketReceive(XmlAttachExt.UseReq));
#endif
        }

    }
}