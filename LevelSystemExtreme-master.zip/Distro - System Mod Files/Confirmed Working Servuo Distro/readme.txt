This is the version of ServUO the system was last tested on. 
This may not be the newest version available. 
